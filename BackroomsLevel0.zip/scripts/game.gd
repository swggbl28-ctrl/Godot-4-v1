extends Node3D
## Backrooms, Level 0: квадратная комната, обои, ковёр, люминесцентные лампы.

const Tex := preload("res://scripts/textures.gd")
const PlayerScript := preload("res://scripts/player.gd")
const HudScript := preload("res://scripts/hud.gd")

const ROOM := 14.0
const HEIGHT := 2.7
const LAMP_ON := 2.6
const LAMP_OFF := 0.25
const LIGHT_ENERGY := 1.7

var _wall_mat: StandardMaterial3D
var _carpet_mat: StandardMaterial3D
var _ceil_mat: StandardMaterial3D

var _lamps: Array = []
var _lights: Array[OmniLight3D] = []
var _flicker_timer := 5.0
var _flicker_left := 0.0
var _flicker_lamp := 0

var _player = null
var _pause_root: Control
var _fps_label: Label
var _fps_accum := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	GameSettings.apply()
	_build_environment()
	_build_materials()
	_build_room()
	_build_lamps()
	_build_player()
	_build_ui()
	if not OS.has_feature("mobile"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_toggle_pause()
	elif what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
		if _pause_root and not get_tree().paused:
			_toggle_pause()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		_toggle_pause()


# ------------------------------------------------------------------- мир

func _build_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.05, 0.04, 0.02)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.62, 0.56, 0.34)
	env.ambient_light_energy = 0.55
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = GameSettings.fog
	env.fog_light_color = Color(0.45, 0.40, 0.22)
	env.fog_density = 0.02
	env.glow_enabled = GameSettings.glow
	env.glow_intensity = 0.7
	env.glow_strength = 0.9
	env.glow_hdr_threshold = 1.0
	env.adjustment_enabled = true
	env.adjustment_saturation = 0.92
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)


func _texture(path: String, img: Image) -> Texture2D:
	if ResourceLoader.exists(path):
		var t = load(path)
		if t is Texture2D:
			return t
	return ImageTexture.create_from_image(img)


func _build_materials() -> void:
	# генерируем текстуры в потоках, чтобы старт был быстрее
	var t_wall := Thread.new()
	var t_carpet := Thread.new()
	t_wall.start(func() -> Image: return Tex.wallpaper_image())
	t_carpet.start(func() -> Image: return Tex.carpet_image())
	var ceil_img: Image = Tex.ceiling_image()
	var wall_img: Image = t_wall.wait_to_finish()
	var carpet_img: Image = t_carpet.wait_to_finish()

	_wall_mat = _mat(_texture("res://textures/wallpaper.jpg", wall_img), 1.5, 0.9)
	_carpet_mat = _mat(_texture("res://textures/carpet.jpg", carpet_img), 1.2, 1.0)
	_ceil_mat = _mat(_texture("res://textures/ceiling.jpg", ceil_img), 1.2, 0.95)


func _mat(tex: Texture2D, tile_m: float, rough: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex
	m.roughness = rough
	m.metallic_specular = 0.25
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3.ONE / tile_m
	return m


func _box(pos: Vector3, size: Vector3, mat: Material, collide: bool = true) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	body.add_child(mi)
	if collide:
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = size
		cs.shape = sh
		body.add_child(cs)
	add_child(body)


func _build_room() -> void:
	var half := ROOM * 0.5
	var t := 0.4
	_box(Vector3(0, -t * 0.5, 0), Vector3(ROOM + 2 * t, t, ROOM + 2 * t), _carpet_mat)
	_box(Vector3(0, HEIGHT + t * 0.5, 0), Vector3(ROOM + 2 * t, t, ROOM + 2 * t), _ceil_mat)
	_box(Vector3(0, HEIGHT * 0.5, -(half + t * 0.5)), Vector3(ROOM + 2 * t, HEIGHT, t), _wall_mat)
	_box(Vector3(0, HEIGHT * 0.5, half + t * 0.5), Vector3(ROOM + 2 * t, HEIGHT, t), _wall_mat)
	_box(Vector3(-(half + t * 0.5), HEIGHT * 0.5, 0), Vector3(t, HEIGHT, ROOM), _wall_mat)
	_box(Vector3(half + t * 0.5, HEIGHT * 0.5, 0), Vector3(t, HEIGHT, ROOM), _wall_mat)

	# плинтусы
	var base_mat := StandardMaterial3D.new()
	base_mat.albedo_color = Color(0.24, 0.18, 0.09)
	base_mat.roughness = 0.8
	_box(Vector3(0, 0.06, -(half - 0.015)), Vector3(ROOM, 0.12, 0.03), base_mat, false)
	_box(Vector3(0, 0.06, half - 0.015), Vector3(ROOM, 0.12, 0.03), base_mat, false)
	_box(Vector3(-(half - 0.015), 0.06, 0), Vector3(0.03, 0.12, ROOM), base_mat, false)
	_box(Vector3(half - 0.015, 0.06, 0), Vector3(0.03, 0.12, ROOM), base_mat, false)


func _build_lamps() -> void:
	# 4 реальных источника света (дёшево для мобильного GPU)
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			var l := OmniLight3D.new()
			l.position = Vector3(sx * 3.5, HEIGHT - 0.45, sz * 3.5)
			l.omni_range = 11.0
			l.light_energy = LIGHT_ENERGY
			l.light_color = Color(1.0, 0.95, 0.76)
			l.light_specular = 0.4
			l.shadow_enabled = false
			add_child(l)
			_lights.append(l)

	var frame_mat := StandardMaterial3D.new()
	frame_mat.albedo_color = Color(0.55, 0.55, 0.50)
	frame_mat.roughness = 0.8

	var xs: Array[float] = [-5.25, -1.75, 1.75, 5.25]
	for x in xs:
		for z in xs:
			var m := StandardMaterial3D.new()
			m.albedo_color = Color(1.0, 0.98, 0.88)
			m.emission_enabled = true
			m.emission = Color(1.0, 0.96, 0.78)
			m.emission_energy_multiplier = LAMP_ON

			var panel := MeshInstance3D.new()
			var pm := BoxMesh.new()
			pm.size = Vector3(1.2, 0.04, 0.6)
			panel.mesh = pm
			panel.material_override = m
			panel.position = Vector3(x, HEIGHT - 0.04, z)
			add_child(panel)

			var frame := MeshInstance3D.new()
			var fm := BoxMesh.new()
			fm.size = Vector3(1.3, 0.03, 0.7)
			frame.mesh = fm
			frame.material_override = frame_mat
			frame.position = Vector3(x, HEIGHT - 0.015, z)
			add_child(frame)

			var li := (2 if x > 0.0 else 0) + (1 if z > 0.0 else 0)
			_lamps.append({"mat": m, "light": _lights[li]})


func _set_lamp(idx: int, on: bool) -> void:
	var d: Dictionary = _lamps[idx]
	var m: StandardMaterial3D = d["mat"]
	m.emission_energy_multiplier = LAMP_ON if on else LAMP_OFF
	var l: OmniLight3D = d["light"]
	l.light_energy = LIGHT_ENERGY if on else LIGHT_ENERGY * 0.82


func _process(delta: float) -> void:
	# случайное мерцание одной из ламп
	if _flicker_left > 0.0:
		_flicker_left -= delta
		_set_lamp(_flicker_lamp, randf() > 0.45)
		if _flicker_left <= 0.0:
			_set_lamp(_flicker_lamp, true)
	else:
		_flicker_timer -= delta
		if _flicker_timer <= 0.0:
			_flicker_timer = randf_range(4.0, 12.0)
			_flicker_left = randf_range(0.25, 0.9)
			_flicker_lamp = randi() % _lamps.size()

	_fps_accum += delta
	if _fps_accum >= 0.5:
		_fps_accum = 0.0
		_fps_label.text = "%d FPS" % Engine.get_frames_per_second()


# ---------------------------------------------------------------- игрок и UI

func _build_player() -> void:
	var p := CharacterBody3D.new()
	p.set_script(PlayerScript)
	p.position = Vector3(0, 0.05, 3)
	p.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(p)
	_player = p


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)

	var hud := Control.new()
	hud.set_script(HudScript)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(hud)
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_player.hud = hud

	var ui := Control.new()
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.theme = GameSettings.make_theme()
	layer.add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_fps_label = Label.new()
	_fps_label.position = Vector2(24, 14)
	_fps_label.modulate = Color(1, 1, 1, 0.6)
	_fps_label.add_theme_font_size_override("font_size", 28)
	ui.add_child(_fps_label)

	var pause_btn := Button.new()
	pause_btn.text = "II"
	pause_btn.custom_minimum_size = Vector2(110, 110)
	pause_btn.pressed.connect(_toggle_pause)
	ui.add_child(pause_btn)
	pause_btn.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 28)
	_player.ignore_ctrls.append(pause_btn)

	var hint := Label.new()
	if OS.has_feature("mobile"):
		hint.text = "Левая половина экрана — ходьба · правая — камера"
	else:
		hint.text = "WASD + мышь · Esc — пауза"
	hint.add_theme_font_size_override("font_size", 34)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(hint)
	hint.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 40)
	var tw := create_tween()
	tw.tween_interval(6.0)
	tw.tween_property(hint, "modulate:a", 0.0, 1.5)
	tw.tween_callback(hint.queue_free)

	# оверлей паузы
	_pause_root = Control.new()
	_pause_root.visible = false
	ui.add_child(_pause_root)
	_pause_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.7)
	_pause_root.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	_pause_root.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 28)
	center.add_child(vb)

	var title := Label.new()
	title.text = "ПАУЗА"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 96)
	title.add_theme_color_override("font_color", Color(0.93, 0.84, 0.45))
	vb.add_child(title)
	vb.add_child(_make_button("ПРОДОЛЖИТЬ", _toggle_pause))
	vb.add_child(_make_button("ГЛАВНОЕ МЕНЮ", _to_menu))


func _make_button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(760, 120)
	b.add_theme_font_size_override("font_size", 52)
	b.pressed.connect(cb)
	return b


func _toggle_pause() -> void:
	var p := not get_tree().paused
	get_tree().paused = p
	_pause_root.visible = p
	if p:
		_player.reset_touches()
	if not OS.has_feature("mobile"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if p else Input.MOUSE_MODE_CAPTURED


func _to_menu() -> void:
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
