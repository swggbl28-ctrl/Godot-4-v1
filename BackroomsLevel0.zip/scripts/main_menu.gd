extends Control

const SCALE_VALUES := [0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
const FPS_VALUES := [30, 60, 90, 120]
const SENS_VALUES := [0.5, 0.75, 1.0, 1.5, 2.0]
const PRESET_NAMES := ["Низкое", "Среднее", "Высокое", "Ультра", "Свой"]
const PRESETS := [
	{"scale": 0.6, "msaa": 0, "aniso": 1, "fog": false, "glow": false},
	{"scale": 0.7, "msaa": 0, "aniso": 2, "fog": true, "glow": false},
	{"scale": 0.8, "msaa": 1, "aniso": 3, "fog": true, "glow": true},
	{"scale": 1.0, "msaa": 2, "aniso": 4, "fog": true, "glow": true},
]

var _title: Label
var _menu_box: Control
var _settings_box: Control
var _ob_preset: OptionButton
var _ob_scale: OptionButton
var _ob_msaa: OptionButton
var _ob_aniso: OptionButton
var _ob_fps: OptionButton
var _ob_fog: OptionButton
var _ob_glow: OptionButton
var _ob_sens: OptionButton


func _ready() -> void:
	theme = GameSettings.make_theme()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

	var bg := ColorRect.new()
	bg.color = Color(0.16, 0.13, 0.05)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_build_menu()
	_build_settings()
	_show_menu()


func _process(_delta: float) -> void:
	# лёгкое мерцание заголовка, как у люминесцентной лампы
	_title.modulate.a = 0.8 if randf() < 0.03 else 1.0


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if _settings_box.visible:
			_show_menu()
		else:
			get_tree().quit()


# ---------------------------------------------------------------- главное меню

func _build_menu() -> void:
	var center := CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_menu_box = center

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 24)
	center.add_child(vb)

	_title = Label.new()
	_title.text = "BACKROOMS"
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_title.add_theme_font_size_override("font_size", 130)
	_title.add_theme_color_override("font_color", Color(0.93, 0.84, 0.45))
	vb.add_child(_title)

	var sub := Label.new()
	sub.text = "LEVEL 0"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 60)
	sub.add_theme_color_override("font_color", Color(0.75, 0.68, 0.38))
	vb.add_child(sub)

	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 30)
	vb.add_child(spacer)

	vb.add_child(_make_button("ИГРАТЬ", _on_play))
	vb.add_child(_make_button("НАСТРОЙКИ ГРАФИКИ", _show_settings))
	vb.add_child(_make_button("ВЫХОД", _on_quit))


func _make_button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(780, 120)
	b.add_theme_font_size_override("font_size", 52)
	b.pressed.connect(cb)
	return b


func _on_play() -> void:
	get_tree().change_scene_to_file("res://scenes/game.tscn")


func _on_quit() -> void:
	get_tree().quit()


func _show_menu() -> void:
	_menu_box.visible = true
	_settings_box.visible = false


func _show_settings() -> void:
	_menu_box.visible = false
	_settings_box.visible = true
	_refresh_controls()


# ------------------------------------------------------------------ настройки

func _build_settings() -> void:
	var center := CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_settings_box = center

	var panel := PanelContainer.new()
	center.add_child(panel)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 22)
	panel.add_child(vb)

	var title := Label.new()
	title.text = "НАСТРОЙКИ ГРАФИКИ"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 64)
	title.add_theme_color_override("font_color", Color(0.93, 0.84, 0.45))
	vb.add_child(title)

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 50)
	grid.add_theme_constant_override("v_separation", 14)
	vb.add_child(grid)

	_ob_preset = _add_option(grid, "Пресет", PRESET_NAMES, _on_preset)
	_ob_scale = _add_option(grid, "Разрешение 3D", ["50%", "60%", "70%", "80%", "90%", "100%"], _on_scale)
	_ob_msaa = _add_option(grid, "Сглаживание", ["Выкл", "MSAA 2x", "MSAA 4x"], _on_msaa)
	_ob_aniso = _add_option(grid, "Анизотропия", ["Выкл", "2x", "4x", "8x", "16x"], _on_aniso)
	_ob_fps = _add_option(grid, "Лимит FPS", ["30", "60", "90", "120"], _on_fps)
	_ob_fog = _add_option(grid, "Туман", ["Выкл", "Вкл"], _on_fog)
	_ob_glow = _add_option(grid, "Свечение ламп", ["Выкл", "Вкл"], _on_glow)
	_ob_sens = _add_option(grid, "Чувствительность", ["0.5x", "0.75x", "1x", "1.5x", "2x"], _on_sens)

	var back := _make_button("НАЗАД", _show_menu)
	back.custom_minimum_size = Vector2(500, 100)
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(back)


func _add_option(grid: GridContainer, label: String, items: Array, cb: Callable) -> OptionButton:
	var row := HBoxContainer.new()
	row.custom_minimum_size = Vector2(840, 100)
	var l := Label.new()
	l.text = label
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(l)
	var ob := OptionButton.new()
	ob.custom_minimum_size = Vector2(320, 90)
	for it in items:
		ob.add_item(str(it))
	ob.item_selected.connect(cb)
	row.add_child(ob)
	grid.add_child(row)
	return ob


func _closest(arr: Array, v: float) -> int:
	var best := 0
	for i in arr.size():
		if absf(float(arr[i]) - v) < absf(float(arr[best]) - v):
			best = i
	return best


func _detect_preset() -> int:
	for i in PRESETS.size():
		var p: Dictionary = PRESETS[i]
		if is_equal_approx(GameSettings.render_scale, float(p["scale"])) \
				and GameSettings.msaa == int(p["msaa"]) \
				and GameSettings.aniso == int(p["aniso"]) \
				and GameSettings.fog == bool(p["fog"]) \
				and GameSettings.glow == bool(p["glow"]):
			return i
	return PRESETS.size()


func _refresh_controls() -> void:
	_ob_preset.select(_detect_preset())
	_ob_scale.select(_closest(SCALE_VALUES, GameSettings.render_scale))
	_ob_msaa.select(clampi(GameSettings.msaa, 0, 2))
	_ob_aniso.select(clampi(GameSettings.aniso, 0, 4))
	_ob_fps.select(_closest(FPS_VALUES, float(GameSettings.fps_cap)))
	_ob_fog.select(1 if GameSettings.fog else 0)
	_ob_glow.select(1 if GameSettings.glow else 0)
	_ob_sens.select(_closest(SENS_VALUES, GameSettings.sensitivity))


func _changed() -> void:
	GameSettings.apply()
	GameSettings.save_settings()
	_ob_preset.select(_detect_preset())


func _on_preset(i: int) -> void:
	if i >= PRESETS.size():
		return
	var p: Dictionary = PRESETS[i]
	GameSettings.render_scale = float(p["scale"])
	GameSettings.msaa = int(p["msaa"])
	GameSettings.aniso = int(p["aniso"])
	GameSettings.fog = bool(p["fog"])
	GameSettings.glow = bool(p["glow"])
	GameSettings.apply()
	GameSettings.save_settings()
	_refresh_controls()


func _on_scale(i: int) -> void:
	GameSettings.render_scale = float(SCALE_VALUES[i])
	_changed()


func _on_msaa(i: int) -> void:
	GameSettings.msaa = i
	_changed()


func _on_aniso(i: int) -> void:
	GameSettings.aniso = i
	_changed()


func _on_fps(i: int) -> void:
	GameSettings.fps_cap = int(FPS_VALUES[i])
	_changed()


func _on_fog(i: int) -> void:
	GameSettings.fog = i == 1
	_changed()


func _on_glow(i: int) -> void:
	GameSettings.glow = i == 1
	_changed()


func _on_sens(i: int) -> void:
	GameSettings.sensitivity = float(SENS_VALUES[i])
	_changed()
