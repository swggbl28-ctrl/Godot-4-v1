extends Control
## Рисует виртуальный джойстик и точку прицела.

var active := false
var origin := Vector2.ZERO
var knob := Vector2.ZERO


func set_stick(is_active: bool, o: Vector2 = Vector2.ZERO, k: Vector2 = Vector2.ZERO) -> void:
	active = is_active
	origin = o
	knob = k
	queue_redraw()


func _draw() -> void:
	draw_circle(size * 0.5, 3.0, Color(1, 1, 1, 0.35))
	if active:
		draw_circle(origin, 140.0, Color(1, 1, 1, 0.08))
		draw_arc(origin, 140.0, 0.0, TAU, 64, Color(1, 1, 1, 0.35), 3.0, true)
		draw_circle(knob, 56.0, Color(1, 1, 1, 0.30))
