extends Node
## Автозагрузка: настройки графики + общая тема интерфейса.

const SAVE_PATH := "user://settings.cfg"

var render_scale: float = 0.8
var msaa: int = 1        # 0 = выкл, 1 = 2x, 2 = 4x
var aniso: int = 3       # 0 = выкл, 1 = 2x, 2 = 4x, 3 = 8x, 4 = 16x
var fps_cap: int = 60
var fog: bool = true
var glow: bool = true
var sensitivity: float = 1.0


func _ready() -> void:
	load_settings()
	apply()


func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	render_scale = float(cfg.get_value("graphics", "render_scale", render_scale))
	msaa = int(cfg.get_value("graphics", "msaa", msaa))
	aniso = int(cfg.get_value("graphics", "aniso", aniso))
	fps_cap = int(cfg.get_value("graphics", "fps_cap", fps_cap))
	fog = bool(cfg.get_value("graphics", "fog", fog))
	glow = bool(cfg.get_value("graphics", "glow", glow))
	sensitivity = float(cfg.get_value("controls", "sensitivity", sensitivity))


func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("graphics", "render_scale", render_scale)
	cfg.set_value("graphics", "msaa", msaa)
	cfg.set_value("graphics", "aniso", aniso)
	cfg.set_value("graphics", "fps_cap", fps_cap)
	cfg.set_value("graphics", "fog", fog)
	cfg.set_value("graphics", "glow", glow)
	cfg.set_value("controls", "sensitivity", sensitivity)
	cfg.save(SAVE_PATH)


func apply() -> void:
	var vp := get_tree().root
	vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
	vp.scaling_3d_scale = clampf(render_scale, 0.5, 1.0)
	vp.msaa_3d = clampi(msaa, 0, 2) as Viewport.MSAA
	vp.anisotropic_filtering_level = clampi(aniso, 0, 4) as Viewport.AnisotropicFiltering
	Engine.max_fps = fps_cap


func make_theme() -> Theme:
	var t := Theme.new()
	t.default_font_size = 40
	for cls in ["Button", "OptionButton"]:
		t.set_stylebox("normal", cls, _box(Color(0.30, 0.25, 0.09, 0.95)))
		t.set_stylebox("hover", cls, _box(Color(0.40, 0.34, 0.12, 0.95)))
		t.set_stylebox("pressed", cls, _box(Color(0.52, 0.44, 0.16, 1.0)))
		t.set_stylebox("focus", cls, StyleBoxEmpty.new())
	t.set_stylebox("panel", "PanelContainer", _box(Color(0.12, 0.10, 0.04, 0.92), 40.0))
	t.set_constant("v_separation", "PopupMenu", 22)
	return t


func _box(c: Color, margin: float = 18.0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(14)
	s.set_border_width_all(2)
	s.border_color = Color(0.75, 0.65, 0.25, 0.6)
	s.set_content_margin_all(margin)
	return s
