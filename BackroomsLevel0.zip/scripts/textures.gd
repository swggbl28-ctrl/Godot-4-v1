extends RefCounted
## Процедурные текстуры Level 0. Генерируются при запуске, внешние файлы не нужны.
## Чтобы использовать настоящие фото, положите wallpaper.jpg / carpet.jpg / ceiling.jpg
## в папку res://textures/ — игра подхватит их автоматически.


static func _noise_bytes(size: int, freq: float, seed_value: int, fbm: bool = true) -> PackedByteArray:
	var n := FastNoiseLite.new()
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.seed = seed_value
	n.frequency = freq
	if fbm:
		n.fractal_type = FastNoiseLite.FRACTAL_FBM
		n.fractal_octaves = 3
	else:
		n.fractal_type = FastNoiseLite.FRACTAL_NONE
	var img := n.get_seamless_image(size, size)
	img.convert(Image.FORMAT_L8)
	return img.get_data()


static func _finish(size: int, data: PackedByteArray) -> Image:
	var img := Image.create_from_data(size, size, false, Image.FORMAT_RGB8, data)
	img.generate_mipmaps()
	return img


static func _put(data: PackedByteArray, o: int, base: Color, shade: float) -> void:
	data[o] = int(clampf(base.r * shade, 0.0, 1.0) * 255.0)
	data[o + 1] = int(clampf(base.g * shade, 0.0, 1.0) * 255.0)
	data[o + 2] = int(clampf(base.b * shade, 0.0, 1.0) * 255.0)


## Жёлтые обои с вертикальными полосами, зернистостью и разводами.
static func wallpaper_image(size: int = 512) -> Image:
	var fine := _noise_bytes(size, 0.30, 11, false)
	var mid := _noise_bytes(size, 0.035, 12)
	var stain := _noise_bytes(size, 0.006, 13)
	var data := PackedByteArray()
	data.resize(size * size * 3)
	var base := Color(0.82, 0.72, 0.34)
	var period: int = size / 4
	for y in size:
		for x in size:
			var i := y * size + x
			var sx := x % period
			var k := 1.0
			if sx < 4:
				k = 0.84
			elif sx < 8:
				k = 1.05
			elif absi(sx - period / 2) < 2:
				k = 0.93
			var shade := k * (0.90 + 0.14 * fine[i] / 255.0) \
					* (0.90 + 0.18 * mid[i] / 255.0) \
					* (0.76 + 0.40 * stain[i] / 255.0)
			_put(data, i * 3, base, shade)
	return _finish(size, data)


## Влажный жёлто-оливковый ковёр с ворсом.
static func carpet_image(size: int = 512) -> Image:
	var fine_a := _noise_bytes(size, 0.85, 21, false)
	var fine_b := _noise_bytes(size, 0.60, 22, false)
	var mid := _noise_bytes(size, 0.08, 23)
	var stain := _noise_bytes(size, 0.008, 24)
	var data := PackedByteArray()
	data.resize(size * size * 3)
	var base := Color(0.56, 0.50, 0.27)
	for i in size * size:
		var fiber := (fine_a[i] + fine_b[i]) / 510.0
		var shade := (0.68 + 0.50 * fiber) \
				* (0.86 + 0.26 * mid[i] / 255.0) \
				* (0.74 + 0.40 * stain[i] / 255.0)
		_put(data, i * 3, base, shade)
	return _finish(size, data)


## Потолочная плитка с перфорацией и швами.
static func ceiling_image(size: int = 256) -> Image:
	var fine := _noise_bytes(size, 0.5, 31, false)
	var mid := _noise_bytes(size, 0.05, 32)
	var data := PackedByteArray()
	data.resize(size * size * 3)
	var base := Color(0.84, 0.82, 0.70)
	var cell: int = size / 2
	for y in size:
		for x in size:
			var i := y * size + x
			var shade := 0.92 + 0.12 * mid[i] / 255.0
			if (x % cell) < 3 or (y % cell) < 3:
				shade *= 0.55
			elif fine[i] > 200:
				shade *= 0.82
			_put(data, i * 3, base, shade)
	return _finish(size, data)
