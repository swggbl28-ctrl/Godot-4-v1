extends CharacterBody3D
## Игрок: левая половина экрана — джойстик ходьбы, правая — поворот камеры.
## На ПК (для проверки): WASD + мышь.

const WALK_SPEED := 2.8
const STICK_RADIUS := 140.0
const GRAVITY := 18.0
const EYE_HEIGHT := 1.6

var hud = null
var ignore_ctrls: Array[Control] = []

var _cam: Camera3D
var _pitch := 0.0
var _move_idx := -1
var _look_idx := -1
var _stick_origin := Vector2.ZERO
var _stick := Vector2.ZERO
var _bob := 0.0
var _mobile := OS.has_feature("mobile")


func _ready() -> void:
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.3
	cap.height = 1.7
	cs.shape = cap
	cs.position.y = 0.85
	add_child(cs)

	_cam = Camera3D.new()
	_cam.position.y = EYE_HEIGHT
	_cam.fov = 60.0
	_cam.near = 0.05
	_cam.far = 80.0
	add_child(_cam)
	_cam.make_current()


func reset_touches() -> void:
	_move_idx = -1
	_look_idx = -1
	_stick = Vector2.ZERO
	if hud:
		hud.set_stick(false)


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			for c in ignore_ctrls:
				if c.is_visible_in_tree() and c.get_global_rect().has_point(t.position):
					return
			var half := get_viewport().get_visible_rect().size.x * 0.5
			if t.position.x < half:
				if _move_idx == -1:
					_move_idx = t.index
					_stick_origin = t.position
					_set_stick(t.position)
			elif _look_idx == -1:
				_look_idx = t.index
		else:
			if t.index == _move_idx:
				_move_idx = -1
				_stick = Vector2.ZERO
				if hud:
					hud.set_stick(false)
			elif t.index == _look_idx:
				_look_idx = -1
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		if d.index == _move_idx:
			_set_stick(d.position)
		elif d.index == _look_idx:
			_rotate_look(d.relative)
	elif event is InputEventMouseMotion and not _mobile and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_rotate_look((event as InputEventMouseMotion).relative * 0.6)


func _set_stick(pos: Vector2) -> void:
	var v := (pos - _stick_origin).limit_length(STICK_RADIUS)
	_stick = v / STICK_RADIUS
	if hud:
		hud.set_stick(true, _stick_origin, _stick_origin + v)


func _rotate_look(rel: Vector2) -> void:
	var s := 0.0032 * GameSettings.sensitivity
	rotate_y(-rel.x * s)
	_pitch = clampf(_pitch - rel.y * s, -1.45, 1.45)
	_cam.rotation.x = _pitch


func _physics_process(delta: float) -> void:
	var mv := _stick
	if not _mobile:
		var k := Vector2.ZERO
		if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
			k.y -= 1.0
		if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
			k.y += 1.0
		if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
			k.x -= 1.0
		if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
			k.x += 1.0
		if k != Vector2.ZERO:
			mv = k.normalized()
	if mv.length() < 0.12:
		mv = Vector2.ZERO

	var dir := global_transform.basis * Vector3(mv.x, 0.0, mv.y)
	var target := dir * WALK_SPEED
	velocity.x = move_toward(velocity.x, target.x, 25.0 * delta)
	velocity.z = move_toward(velocity.z, target.z, 25.0 * delta)
	if is_on_floor():
		velocity.y = 0.0
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()

	var speed := Vector2(velocity.x, velocity.z).length()
	if speed > 0.3 and is_on_floor():
		_bob += delta * speed * 2.6
		_cam.position.y = EYE_HEIGHT + sin(_bob * 2.0) * 0.025
		_cam.position.x = cos(_bob) * 0.015
	else:
		_cam.position.y = lerpf(_cam.position.y, EYE_HEIGHT, 8.0 * delta)
		_cam.position.x = lerpf(_cam.position.x, 0.0, 8.0 * delta)
